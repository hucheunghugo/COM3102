-- phpMyAdmin SQL Dump
-- version 5.2.0
-- https://www.phpmyadmin.net/
--
-- 主機： 127.0.0.1
-- 產生時間： 2023-12-02 17:17:17
-- 伺服器版本： 10.4.27-MariaDB
-- PHP 版本： 8.2.0

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- 資料庫： `com3102`
--

-- --------------------------------------------------------

--
-- 資料表結構 `event`
--

CREATE TABLE `event` (
  `event_id` int(11) NOT NULL,
  `event_name` char(50) NOT NULL DEFAULT '',
  `event_date` date NOT NULL,
  `event_start_time` time DEFAULT NULL,
  `event_end_time` time DEFAULT NULL,
  `user_id` varchar(50) NOT NULL DEFAULT '',
  `description` text DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- 傾印資料表的資料 `event`
--

INSERT INTO `event` (`event_id`, `event_name`, `event_date`, `event_start_time`, `event_end_time`, `user_id`, `description`) VALUES
(1, 'Holiday', '2024-12-04', NULL, NULL, '13', NULL),
(2, 'Exam', '2023-12-02', '12:00:00', '13:00:00', '14', NULL),
(3, 'Qwe', '2023-12-07', '00:00:00', '00:00:00', '14', ''),
(4, 'ert', '2023-12-06', '00:00:00', '00:00:00', '14', '123');

-- --------------------------------------------------------

--
-- 資料表結構 `friend_list`
--

CREATE TABLE `friend_list` (
  `id` int(11) NOT NULL,
  `user_id` int(11) DEFAULT NULL,
  `friend_id` int(11) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- 傾印資料表的資料 `friend_list`
--

INSERT INTO `friend_list` (`id`, `user_id`, `friend_id`) VALUES
(1, 13, 14),
(2, 14, 17),
(3, 17, 14),
(4, 14, 16),
(5, 16, 14);

-- --------------------------------------------------------

--
-- 資料表結構 `grades`
--

CREATE TABLE `grades` (
  `id` int(11) NOT NULL,
  `student_name` varchar(255) NOT NULL,
  `subject` varchar(255) NOT NULL,
  `grade` text NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- 傾印資料表的資料 `grades`
--

INSERT INTO `grades` (`id`, `student_name`, `subject`, `grade`) VALUES
(1, 'asd', 'sada', 'A'),
(27, '21321', '213', '2'),
(28, '21321', '213', '2'),
(29, 'asd', 'sad', 'A'),
(30, 'asd', 'sad', 'A'),
(31, 'asd', 'sad', 'A'),
(32, 'sad', 'sadsa', 'A'),
(33, '', '', ''),
(34, '', '', ''),
(35, '', '', ''),
(36, '', '', ''),
(37, '', '', ''),
(38, '', '', ''),
(39, '', '', ''),
(40, '', '', ''),
(41, '', '', ''),
(42, '', '', ''),
(43, '', '', ''),
(44, '', '', ''),
(45, '', '', ''),
(46, '', '', ''),
(47, '', '', ''),
(48, '', '', ''),
(49, '', '', ''),
(50, '', '', ''),
(51, '', '', ''),
(52, '', '', ''),
(53, '', '', ''),
(54, 'asd', 'sad', 'sad'),
(55, 'asd', 'sad', 'A');

-- --------------------------------------------------------

--
-- 資料表結構 `parti`
--

CREATE TABLE `parti` (
  `event_id` int(11) NOT NULL,
  `user_id` varchar(50) NOT NULL,
  `alert` binary(1) NOT NULL DEFAULT '1'
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- 傾印資料表的資料 `parti`
--

INSERT INTO `parti` (`event_id`, `user_id`, `alert`) VALUES
(1, '13', 0x31),
(1, '14', 0x31),
(1, '16', 0x31),
(2, '14', 0x31);

-- --------------------------------------------------------

--
-- 資料表結構 `photo`
--

CREATE TABLE `photo` (
  `photo_id` int(11) NOT NULL,
  `file_name` varchar(50) NOT NULL DEFAULT '0',
  `user_id` varchar(50) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- 傾印資料表的資料 `photo`
--

INSERT INTO `photo` (`photo_id`, `file_name`, `user_id`) VALUES
(7, '11.jpg', NULL),
(8, '13.jpg', NULL);

-- --------------------------------------------------------

--
-- 資料表結構 `users`
--

CREATE TABLE `users` (
  `Userid` int(11) NOT NULL,
  `username` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_bin NOT NULL,
  `password` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_bin NOT NULL,
  `token` varchar(32) CHARACTER SET utf8mb4 COLLATE utf8mb4_bin DEFAULT NULL,
  `email` varchar(50) CHARACTER SET utf8mb4 COLLATE utf8mb4_bin NOT NULL,
  `programme` text CHARACTER SET utf8mb4 COLLATE utf8mb4_bin DEFAULT NULL,
  `year_of_entrance` varchar(4) CHARACTER SET utf8mb4 COLLATE utf8mb4_bin DEFAULT NULL,
  `sid` varchar(10) CHARACTER SET utf8mb4 COLLATE utf8mb4_bin DEFAULT NULL,
  `last_login_time` datetime DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- 傾印資料表的資料 `users`
--

INSERT INTO `users` (`Userid`, `username`, `password`, `token`, `email`, `programme`, `year_of_entrance`, `sid`, `last_login_time`) VALUES
(1, 'Admin', 'Admin', 'fcae4d9c625ed761b5a192cfdf9c916b', 'admin@admin', NULL, NULL, NULL, NULL),
(13, 'user', 'user', 'c0e8839ca42d476f52ba12a55441e4a4', 'abc@abc', '', '', '', NULL),
(14, 'Hugo', 'Hugo', '5526fca83656cf5662d827f3ba2b490e', '2503hugo@gmail.com', 'aaa', '2003', 'as23', NULL),
(16, 'user1', 'uesr1', NULL, 'asd@sads', 'aaa', '2003', 'as23', NULL),
(17, 'user2', 'uesr2', NULL, 'sada2@asdasd', 'aaa', '2003', 'as23', NULL);

--
-- 已傾印資料表的索引
--

--
-- 資料表索引 `event`
--
ALTER TABLE `event`
  ADD PRIMARY KEY (`event_id`);

--
-- 資料表索引 `friend_list`
--
ALTER TABLE `friend_list`
  ADD KEY `id` (`id`);

--
-- 資料表索引 `grades`
--
ALTER TABLE `grades`
  ADD PRIMARY KEY (`id`);

--
-- 資料表索引 `parti`
--
ALTER TABLE `parti`
  ADD KEY `索引 1` (`event_id`,`user_id`);

--
-- 資料表索引 `photo`
--
ALTER TABLE `photo`
  ADD PRIMARY KEY (`photo_id`);

--
-- 資料表索引 `users`
--
ALTER TABLE `users`
  ADD PRIMARY KEY (`Userid`);

--
-- 在傾印的資料表使用自動遞增(AUTO_INCREMENT)
--

--
-- 使用資料表自動遞增(AUTO_INCREMENT) `event`
--
ALTER TABLE `event`
  MODIFY `event_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=5;

--
-- 使用資料表自動遞增(AUTO_INCREMENT) `friend_list`
--
ALTER TABLE `friend_list`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=6;

--
-- 使用資料表自動遞增(AUTO_INCREMENT) `grades`
--
ALTER TABLE `grades`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=56;

--
-- 使用資料表自動遞增(AUTO_INCREMENT) `photo`
--
ALTER TABLE `photo`
  MODIFY `photo_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=9;

--
-- 使用資料表自動遞增(AUTO_INCREMENT) `users`
--
ALTER TABLE `users`
  MODIFY `Userid` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=18;

--
-- 已傾印資料表的限制式
--

--
-- 資料表的限制式 `parti`
--
ALTER TABLE `parti`
  ADD CONSTRAINT `FK_parti_event` FOREIGN KEY (`event_id`) REFERENCES `event` (`event_id`) ON DELETE NO ACTION ON UPDATE NO ACTION;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
