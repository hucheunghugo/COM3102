<?php
session_start();
error_reporting(E_ALL);
ini_set('display_errors', 1);
require './db_connect.php';

function sanitize($input) {
    global $conn;
    return mysqli_real_escape_string($conn, trim($input));
}

// Retrieve the userid from the session
$userid = $_SESSION['userid'];

$requestData = json_decode(file_get_contents('php://input'), true);

$date = $requestData['date'];
$month = $requestData['month'];
$year = $requestData['year'];


// Prepare the SQL query to retrieve the event
$query = "SELECT *  FROM event 
INNER JOIN parti ON event.event_id = parti.event_id 
INNER JOIN users ON event.user_id = users.Userid 
WHERE parti.user_id = '$userid' AND event.event_date = '$year-$month-$date'";

// Execute the query
$result = $conn->query($query);

if ($result->num_rows > 0) {
    // Events found, return all rows
    $events = [];
    while ($row = $result->fetch_assoc()) {
        $events[] = $row;
    }
    echo json_encode(["events" => $events]);
} else {
    // No events found
    echo json_encode(["events" => []]);
}

?>