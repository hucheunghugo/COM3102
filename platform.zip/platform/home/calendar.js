document.addEventListener("DOMContentLoaded", function() {
  var calendarTable = document.querySelector(".calendar-table");
  var monthYear = document.querySelector(".month-year");
  var prevBtn = document.querySelector(".prev-btn");
  var nextBtn = document.querySelector(".next-btn");

  var currentDate = new Date();
  var currentMonth = currentDate.getMonth();
  var currentYear = currentDate.getFullYear();

  renderCalendar(currentMonth, currentYear);

  prevBtn.addEventListener("click", function() {
    currentMonth--;
    if (currentMonth < 0) {
      currentMonth = 11;
      currentYear--;
    }
    renderCalendar(currentMonth, currentYear);
  });

  nextBtn.addEventListener("click", function() {
    currentMonth++;
    if (currentMonth > 11) {
      currentMonth = 0;
      currentYear++;
    }
    renderCalendar(currentMonth, currentYear);
  });

  async function renderCalendar(month, year) {
    var firstDay = new Date(year, month, 1);
    var lastDay = new Date(year, month + 1, 0);
    var daysInMonth = lastDay.getDate();
    var startDay = firstDay.getDay();
    var endDay = lastDay.getDay();

    var tbody = calendarTable.querySelector("tbody");
    tbody.innerHTML = "";

    monthYear.textContent = getMonthName(month) + " " + year;

    var date = 1;
    for (var i = 0; i < 6; i++) {
      var row = document.createElement("tr");
      for (var j = 0; j < 7; j++) {
        if (i === 0 && j < startDay) {
          var cell = document.createElement("td");
          cell.classList.add("other-month");
          row.appendChild(cell);
        } else if (date > daysInMonth) {
          break;
        } else {
          var cell = document.createElement("td");
          cell.textContent = date;

          // Check if there are events on the current date
          try {
            const events = await getEventByDateAndParticipant(date, month, year);
            if (events && events.length > 0) {
              
                var dot = document.createElement("span");
                dot.classList.add("event-dot");
                cell.appendChild(dot);
  
                // Add a click event listener to the cell
                cell.addEventListener("click", function () {
                  performAction(events);
                });
              
            }
          } catch (error) {
            console.error(error);
          }
  
          if (
            date === currentDate.getDate() &&
            month === currentDate.getMonth() &&
            year === currentDate.getFullYear()
          ) {
            cell.classList.add("today");
          }
          row.appendChild(cell);
          date++;
        }
      }
      tbody.appendChild(row);
    }
  }

  async function getEventByDateAndParticipant(date, month, year) {
    try {
      const response = await fetch("../check_event.php", {
        method: "POST",
        body: JSON.stringify({
          date: date.toString().padStart(2, "0"),
          month: (month + 1).toString().padStart(2, "0"),
          year: year.toString(),
        }),
      });
      const data = await response.json();
      return data.events; // Return an array of events
    } catch (error) {
      throw new Error("Failed to get event: " + error.message);
    }
  }

  function getMonthName(month) {
    var monthNames = [
      "January",
      "February",
      "March",
      "April",
      "May",
      "June",
      "July",
      "August",
      "September",
      "October",
      "November",
      "December"
    ];
    return monthNames[month];
  }

  function performAction(events) {
    var popupContent = document.createElement("div");
    popupContent.classList.add("popup-content");
  
    for (var i = 0; i < events.length; i++) {
      var event = events[i];
  
      var username = document.createElement("p");
      username.textContent = "Created by: " + event.username;
      popupContent.appendChild(username);
  
      var eventName = document.createElement("p");
      eventName.textContent = "Event Name: " + event.event_name;
      popupContent.appendChild(eventName);
  
      if (event.description) {
        var description = document.createElement("p");
        description.textContent = "Description: " + event.description;
        popupContent.appendChild(description);
      }
  
      if (event.event_start_time) {
        var startTime = document.createElement("p");
        startTime.textContent = "Start Time: " + event.event_start_time;
        popupContent.appendChild(startTime);
      }
  
      if (event.event_end_time) {
        var endTime = document.createElement("p");
        endTime.textContent = "End Time: " + event.event_end_time;
        popupContent.appendChild(endTime);
      }
  
      var divider = document.createElement("hr");
      popupContent.appendChild(divider);
    }
  
    var closeButton = document.createElement("button");
    closeButton.textContent = "Close";
    closeButton.classList.add("close-button");
    closeButton.addEventListener("click", function () {
      document.body.removeChild(popup);
    });
    popupContent.appendChild(closeButton);
  
    var popup = document.createElement("div");
    popup.classList.add("popup");
    popup.appendChild(popupContent);
  
    document.body.appendChild(popup);
  }
});




