<?php
session_start();

require '../db_connect.php';

function sanitize($input) {
    global $conn;
    return mysqli_real_escape_string($conn, trim($input));
}




// Retrieve the userid from the session
$userid = $_SESSION['userid'];

//Fetching Username
$sql = "SELECT username, token, sid FROM users WHERE Userid = $userid";
$result = $conn->query($sql);

if ($result) {
    $row = $result->fetch_assoc();
    $username = strval($row['username']);
    $dbToken = $row['token'];
    $sid = $row['sid'];

    if (isset($_POST['addEvent'])) {
        $date = sanitize($_POST['date']);
        $event = sanitize($_POST['event']);
        $description = sanitize($_POST['description']);
        $start_time = sanitize($_POST['start_time']);
        $end_time = sanitize($_POST['end_time']);
        $parti = sanitize($_POST['parti']);
        $partiArray = array_unique(explode(",", $parti));
        $arrlength = count($partiArray);
        $reminder = sanitize($_POST['remind']);
        $successMessageDisplayed = false;
    
        $sql = "INSERT INTO event ( event_name, event_date, event_start_time, event_end_time, user_id,  description)
        VALUES ('$event', '$date', " . ($start_time !== '' ? "'$start_time'" : "NULL") . ", " . ($end_time !== '' ? "'$end_time'" : "NULL") . ", '$userid', '$description')";
    
        if ($conn->query($sql) === TRUE) {
            echo "<script>alert('Event added successfully.');</script>";
            $successMessageDisplayed = true;
        } else {
            echo "Error: " . $sql . "<br>" . $conn->error;
        }
        $eventid = mysqli_insert_id($conn);
        if ($arrlength != 0){
            for ($i = 0; $i < $arrlength; $i++) {
                $sql = "INSERT INTO parti (event_id, user_id, alert)
                        VALUES ('$eventid', '$partiArray[$i]', '$reminder')";
                if ($conn->query($sql) === FALSE && !$successMessageDisplayed) {
                    echo "Error: " . $sql . "<br>" . $conn->error;
                }
            }
        }
        echo "<script>setTimeout(function() { window.location.href = 'redirect.php'; }, 0);</script>";
    }

} else {
    echo "Error executing the query: " . $conn->error;
}


if (isset($_COOKIE['token'])) {
    $cookieToken = $_COOKIE['token'];
    if ($dbToken !== $cookieToken) {
        // Database token and cookie token don't match, redirect to the login page
        echo "<script>alert('Token mismatch. Please login again.');</script>";
        echo "<script>window.setTimeout(function(){ window.location.href = '../'; }, 1000);</script>";
        exit;
    }
} else {
    // Cookie token not set, redirect to the login page
    echo "<script>alert('Token mismatch. Please login again.');</script>";
    echo "<script>window.setTimeout(function(){ window.location.href = '../'; }, 1000);</script>";
    exit;
}


if (isset($_POST['social'])) {
    header("Location: social_network/social_network.php");
    exit;
} elseif (isset($_POST['grade'])) {
    header("Location: grade_db/grade_db.php");
    exit;
} elseif (isset($_POST['info'])) {
    header("Location: my_info/my_info.php");
    exit;
} elseif (isset($_POST['users_data'])) {
    header("Location: users_data/users_data.php");
    exit;
}
?>

<!DOCTYPE html>
<html>
<head>
    <title>My Website</title>
    <link rel="stylesheet" type="text/css" href="../style.css">
    <script src="https://code.jquery.com/jquery-3.6.0.min.js"></script>
    <script src="calendar.js"></script>
    <script>
        function redirectToLogin() {
            window.location.replace("../");
        }
            function openAlert() {
            var alertwindow = document.getElementById('alertwindow');
            var overlay = document.getElementById('overlay');
            alertwindow.style.display = 'block';
            overlay.style.display = 'block';
            }
            function closeAlert() {
            var alertwindow = document.getElementById('alertwindow');
            var overlay = document.getElementById('overlay');
            alertwindow.style.display = 'none';
            overlay.style.display = 'none';
        }
        window.addEventListener(function() {
            openAlert();
        });
    </script>
    <style>
        .alert-container {
            display: flex;
            flex-direction: column;
        }
    </style>
    
</head>
<body>
    <div class="container">
        <div class="navbar">
            <div class="navbar-left">
                <span class="username"><?php echo $username; ?></span>
            </div>
            <form action="home.php" method="post">
                <div class="navbar-mid">
                    <button type="submit" name="calendar" class="nav-button">Calendar</button>
                    <?php if (!empty($sid)) { ?>
                       <button type="submit" name="social" class="nav-button">Social Networking</button>
                    <?php } ?>
                    <button type="submit" name="grade" class="nav-button">Grade Database</button>
                    <button type="submit" name="info" class="nav-button">My Information</button>
                    <?php if ($username=="Admin") { ?>
                       <button type="submit" name="users_data" class="nav-button">Students Login Data</button>
                    <?php } ?>
                </div>
            </form>
            <div class="navbar-right">
                <button class="logout-button" onclick="redirectToLogin()">Log Out</button>
            </div>
        </div>
        <?php
            $alert = "SELECT * FROM event JOIN parti ON event.event_id = parti.event_id WHERE parti.user_id = $userid AND parti.alert = 1 AND event_date BETWEEN CURDATE() AND DATE_ADD(CURDATE(), INTERVAL 7 DAY) order by event.event_date, event.event_start_time, event.event_end_time";
            $alertresult = $conn->query($alert);
            $event_no = 0;

            if ($alertresult && $alertresult->num_rows > 0) {
                ?>
                <div class="alertwindow" id="alertwindow">
                    <h1>Event Reminder <button class="close-btn" onclick="closeAlert('closewindow')" style="vertical-align: middle;">Close</button></h1>
                    <h2>You have events this week!</h2>
                    <?php
                    while ($row = $alertresult->fetch_assoc()) {
                        $eventname = $row['event_name'];
                        $eventdate = $row['event_date'];
                        if ($row['event_start_time'])
                            $eventstart = date("H:i", strtotime($row['event_start_time']));
                        else
                            $eventstart = null;
                        if ($row['event_end_time'])
                            $eventend = date("H:i", strtotime($row['event_end_time']));
                        else
                            $eventend = null;
                        $event_no = $event_no + 1;
                        echo '<span style="font-size: 21px;">Event ' . $event_no . '</span>' . "<br>";
                        echo "Name: " . $eventname . "<br>";
                        echo "Date: " . $eventdate . "<br>";
                        echo "Time: " . $eventstart . " - " . $eventend . "<br><br>";
                    }
                    ?>
                </div>
                <?php
            } elseif ($alertresult === false) {
                echo "Error executing the query: " . $conn->error;
            }
        ?>
        <div class="functionality">
            <h2>Calendar</h2>
            <div class="calendar">
                <div class="calendar-header">
                    <button class="prev-btn">&lt;</button>
                    <div class="month-year"></div>
                    <button class="next-btn">&gt;</button>
                </div>  
                <table class="calendar-table">
                    <thead>
                        <tr>
                            <th>Sun</th>
                            <th>Mon</th>
                            <th>Tue</th>
                            <th>Wed</th>
                            <th>Thu</th>
                            <th>Fri</th>
                            <th>Sat</th>
                        </tr>
                    </thead>
                    <tbody></tbody>
                </table>
                </div>
            </div>
            <div class="add-form">
                <h3>Add Event</h3>
                <form action="home.php" method="post">
                    <input type="text" name="event" id="event-input" placeholder="Event Name" required>
                    <?php echo "<br>"; ?>
                    <input type="date" name="date" id="date-input" placeholder="Date" required>
                    <?php echo "&nbsp"; ?>
                    <input type="time" name="start_time" id="start-time-input" placeholder="Start Time" >
                    <?php echo "-"; ?>
                    <input type="time" name="end_time" id="end-time-input" placeholder="End Time" >
                    <?php echo "<br><br>"; ?>
                    <input type="text" name="description" id="description-input" placeholder="Description">
                    <?php echo "<br>"; ?>
                    <input type="text" name="parti" id="parti-input" placeholder="Participants (separate with commas(,))" >
                    <?php echo "Reminder: "; ?>
                    <label>
                    <input type="radio" name="remind" value="1" checked> Yes
                    </label>
                    <label>
                        <input type="radio" name="remind" value="0"> No
                    </label>
                    <?php echo "<br><br>"; ?>
                    <button class="submit-btn" type="submit" name="addEvent" id="add-btn">Add Event</button>
                </form>
            </div>
        </div>
        
    </div>

</body>
</html>
