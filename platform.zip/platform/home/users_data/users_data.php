<?php
session_start();

require '../../db_connect.php';

function sanitize($input) {
    global $conn;
    return mysqli_real_escape_string($conn, trim($input));
}

// Retrieve the userid from the session
$userid = $_SESSION['userid'];

//Fetching Username
$sql = "SELECT username FROM users WHERE Userid = $userid";
$result = $conn->query($sql);

if ($result) {
    $row = $result->fetch_assoc();
    $username = strval($row['username']);

} else {
    echo "Error executing the query: " . $conn->error;
}



if (isset($_POST['calendar'])) {
    header("Location: ../home.php");
    exit;
} elseif (isset($_POST['grade'])) {
    header("Location: ../grade_db/grade_db.php");
    exit;
} elseif (isset($_POST['info'])) {
    header("Location: ../my_info/my_info.php");
    exit;
} elseif (isset($_POST["users_data"])) {
    header("Location: ./users_data.php");
    exit;
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>Users Data</title>
  <link rel="stylesheet" href="../../style.css">
  
</head>
<script>
  function redirectToLogin() {
    window.location.replace("../../");
  }
</script>
<body>

  <div class="container">
    <div class="navbar">
      <div class="navbar-left">
        <span class="username"><?php echo $username; ?></span>
      </div>
      <form action="users_data.php" method="post">
        <div class="navbar-mid">
            <button type="submit" name="calendar" class="nav-button">Calendar</button>
            <button type="submit" name ="grade" class="nav-button">Grade Database</button>
            <button type="submit" name ="info" class="nav-button">My Information</button>
            <button type="submit" name="users_data" class="nav-button">Students Login Data</button>
        </div>
      </form>

      <div class="navbar-right">
          <button class="logout-button" onclick="redirectToLogin()">Log Out</button>
      </div>
    </div>

    <div class="users-container">
      <h2>Students Login Data</h2>
      <ul>
        <?php  
        //Fetching same major as user
        $sql = "SELECT * FROM users Where sid IS NOT NULL";
        $result = $conn->query($sql);
        if ($result) {
          if ($result->num_rows > 0) {
            // Loop through each row and retrieve the user data
            while ($row = $result->fetch_assoc()) {
              $user = $row['username'];                  
              $login_time = $row['last_login_time'];
        ?>
            <li>
              Username: <?php echo $user; ?><br>
              Last Login Time: <?php if($login_time){echo $login_time;} else {echo "No Login Record";} ?>
            </li>
        <?php
            }
          }
        } else {
            echo "Error executing the query: " . $conn->error;
        }

        ?>
      </ul>
    </div>

  </div>
</body>
</html>