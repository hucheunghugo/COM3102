

<!DOCTYPE html>
<html>
<head>
</head>
<body>
    <?php
    echo "<script>setTimeout(function() { window.location.href = 'home.php'; }, 0);</script>";
    ?>

</body>
</html>